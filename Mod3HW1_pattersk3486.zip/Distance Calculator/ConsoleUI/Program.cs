﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
//Kevin Patterson
//CSC-253-0002
//10-06-20
//Distance Calculator

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Distance = Speed x Time
            int speed;
            int time;
            int distance;
            Console.WriteLine("Enter a speed");
            speed = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the time");
            time = Convert.ToInt32(Console.ReadLine());
            distance = time * speed;
            Console.WriteLine("The distance is " + distance);
            Console.ReadLine();

        }
    }
}
