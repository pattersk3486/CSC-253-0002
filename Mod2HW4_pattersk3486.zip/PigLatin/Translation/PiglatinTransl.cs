﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Translation
{
    public class PiglatinTransl
    {
        public static string PigTransl(string[] someString)
        {
            
            //string words;
            //string letters;
            int count = 0;
            foreach(string words in someString)
            {
                Console.WriteLine("Please enter a string: ");
                Console.WriteLine("--------------------------");
                string sentence = Console.ReadLine();
                if(someString.Length < 0)
                {
                    
                    string[] token = words.Split(' ');
                    count++;
                    return words;
                }
                return sentence;

            }
            
        }
        
    }
}
