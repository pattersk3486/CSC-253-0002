﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Kevin Patterson
//CSC-253-0003
//Hospital Charges
//9-5-20
namespace ConsoleUI
{
    class Program
    {
        public static void Main(string[] args)
        {


            Console.WriteLine(CalcStayCharges());


            Console.WriteLine(CalcMiscCharges());


            Console.WriteLine(CalcTotalCharges());

        }
       public static double CalcStayCharges()
        {

            int days;
            double stayTotal;
            Console.WriteLine("How many days did the patient stay?");
            int.TryParse(Console.ReadLine(), out days);
            stayTotal = 350 * days;
            Console.WriteLine("The total cost of hospital stay is:", stayTotal);
            return stayTotal;

        }
        public static double CalcMiscCharges()
        {

            //int medication;
            //int surgical;
            //int lab;
            //int rehab;
            double miscTotal;
            Console.WriteLine("What is the cost of medication?");
            double.TryParse(Console.ReadLine(), out double medication);
            Console.WriteLine("What is the surgical cost?");
            double.TryParse(Console.ReadLine(), out double surgical);
            Console.WriteLine("What is the lab cost?");
            double.TryParse(Console.ReadLine(), out double lab);
            Console.WriteLine("What is the rehabilitation cost?");
            double.TryParse(Console.ReadLine(), out double rehab);
            miscTotal = medication + surgical + lab + rehab;
            Console.WriteLine("The total for Misc Charges is:", miscTotal);
            return miscTotal;



        }
        public static double CalcTotalCharges()
        {
            double finalTotal;
            double stayTotal = CalcStayCharges();
            double miscTotal = CalcMiscCharges();
            finalTotal = stayTotal + miscTotal;
            Console.WriteLine($"The grand total is:{finalTotal}");
            //Console.ReadLine();
            return finalTotal;


        }



    }
}
