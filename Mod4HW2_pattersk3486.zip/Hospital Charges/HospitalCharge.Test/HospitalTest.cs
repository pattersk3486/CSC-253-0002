﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
namespace HospitalCharge.Test
{
    public class HospitalTest
    {
        [Theory]
        [InlineData(1, 350, 0, 0, 0, 0, 0, 350)]
        [InlineData(1, 350, 0, 0, 0, 0, 0, 200)]
        [InlineData(1, 350, 10, 0, 0, 0, 0, 360)]
        public void CalcTotalCharges(int days, double stayTotal, double miscTotal, double medication, double surgical,
            double lab, double rehab, double finalTotal)
        {
            //Arrange
            double expected = finalTotal;
            //Act
            double actual = finalTotal = stayTotal + miscTotal;
            //Assert
            Assert.Equal(expected, actual);
        }
    }
}
