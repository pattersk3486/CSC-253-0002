﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Kevin Patterson
//9-19-20
//CSC-253-0002
//Word Count
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            StringWordCount();
        }
        public static string StringWordCount()
        {
            String wordcount;
            
            
            
            Console.WriteLine("Enter some words and the program will count those words: ");
            wordcount = Console.ReadLine();
            string[] words = wordcount.Split(' ');
            Console.WriteLine("Number of words are: " +words.Length);
            Console.ReadLine();
            return wordcount;
            //Console.WriteLine(words);
        }
    }
}
