﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Kevin Patterson
//CSC-253-0002
//9/29/2020
//Frequent Character
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {


            string chars;

            while (chars.Length > 0)
            {
                Console.WriteLine("Enter a sentence and this program will find the most frequent character: ");
                chars = Console.ReadLine();

                //int count = 0;
                chars = Console.ReadLine();
                foreach (int letters in chars)
                {
                    //char letters;
                    string[] characters = chars.Split(' ');
                    

                    Console.WriteLine(letters.ToString(chars));
                    

                }
                Console.WriteLine("The most common character is: ", chars.Length);
            }
            Console.ReadLine();




        }
       
    }
}
