﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using RandomNumbersGenerator;

//Kevin Patterson
//CSC 253-0002
//Rnadom Number File Writer & File Reader
//10/23/2020
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamWriter outputFile;
            int number;

            try
            {
                outputFile = File.CreateText("Random Number Generator.txt");
                StandardMessage.GetTheNumber();
                number = RandomGenerator.GetUserInput();
                RandomGenerator.SendToFile(outputFile, number);
                RandomGenerator.CloseTheFile(outputFile);
                StandardMessage.CompleteTask();
                
            }
            catch (Exception)
            {
                Console.WriteLine("File not found");
            }
            

            StreamReader inputFile;
            string find;
            string num;
            int sum = 0;
            int numbers = 0;      
            Console.WriteLine("Please enter the file name.");
            find = Console.ReadLine();
            try
            {
                inputFile = File.OpenText("Random Number Generator.txt");
                while (!inputFile.EndOfStream)
                {
                    ++numbers;
                    num = inputFile.ReadLine();
                    Console.WriteLine(num);
                    int.TryParse(num, out number);
                    sum += number;
                }
                inputFile.Close();
                Console.WriteLine($"The sum is: {sum}");
                Console.WriteLine($"The amount of numbers shown: {numbers}");
                Console.ReadLine();
            }
            catch (Exception)
            {
                Console.WriteLine("Could not fine stated filename");
            }


            




        }
    }
}
