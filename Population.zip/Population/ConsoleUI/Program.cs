﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
//Kevin Patterson
//CSC 253-0002
//Population
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int startNumber;
            double dailyIncrease;
            //int days;
            //double population;
            Console.WriteLine("What is the starting number of bacteria?");
            int.TryParse(Console.ReadLine(), out startNumber);
            Console.WriteLine("What is the daily increase of the bacteria?(Percentage)");
            double.TryParse(Console.ReadLine(), out dailyIncrease);
            Console.WriteLine("How many days is the organism staying out?");
            Console.ReadLine();

            for ( int days = 1; days < 11; days++)
            {
                
                Console.WriteLine("Day {0}:",days);
                
               double population = startNumber * (dailyIncrease + days);
                Console.WriteLine(population);
                


            }
            Console.ReadLine();







        }
    }
}
