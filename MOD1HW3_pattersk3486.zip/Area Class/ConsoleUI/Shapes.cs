﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class Shapes
    {
        public static double Area(double radius)
        {
            //pi*r^2
            return Math.PI * (radius * radius);
        }
        public static int Area(int w, int l)
        {
            //w*l
            return w * l;
        }
        public static double Area(double r, double h)
        {
            //2*pi*r^2 + h(2*pi*r)
            return 2 * Math.PI * (r * r) + h * (2 * Math.PI * r);
        }
    }
}
