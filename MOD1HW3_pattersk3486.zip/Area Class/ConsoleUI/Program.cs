﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Kevin Patterson
//9/11/20
//Area Class
//CSC-253-0002
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Shapes.Area(5));
            Console.WriteLine(Shapes.Area(4, 8));
            Console.WriteLine(Shapes.Area(3.2, 7));
            Console.ReadLine();
            
        }
    }
}
