﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Kevin Patterson
//9-19-20
//CSC-253-0002
//Word Count
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            StringWordCount();
        }
        public static string StringWordCount()
        {
            String wordcount;
            //char letter;
            int count = 0;
            Console.WriteLine("Enter some words and the program will count those words: ");
            wordcount = Console.ReadLine();
            string[] words = wordcount.Split(' ');
            
            foreach (char letter in wordcount)
            {
                string[] index = wordcount.Split(letter);

                if (index = 1; index <= wordcount.Length; count++)
                {

                    string[] token = wordcount.Split(letter);
                    Console.WriteLine("The average number of letters per word is: " + token.Length);
                    count++;
                    token / index;
                }
                
                count++;
            }
            
            Console.WriteLine("Number of words are: " + words.Length);
            //Console.WriteLine("The average number of letters per word is: " + token.Length);
            Console.ReadLine();
            return wordcount;

            
            
           
            

            
            
            
            
            //Console.WriteLine(words);
        }
    }
}
