﻿using CarClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//March 23, 2020
//CSC 153
//Kevin Patterson
//Car Class
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            Car thisCar = new Car();
            do
            {
                Console.WriteLine(StandardMessages.DisplayMainMenu());
                switch(Console.ReadLine())
                {
                    case "1":
                        BuildCar.BuildACar(thisCar);
                        break;
                    case "2":
                        thisCar.Accelerate();
                        break;
                    case "3":
                        thisCar.Break();
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        StandardMessages.Default();
                        break;
                }
                Console.WriteLine($"This car is going {thisCar.Speed} MPH");

            } while (exit == false);
        }
    }
}
