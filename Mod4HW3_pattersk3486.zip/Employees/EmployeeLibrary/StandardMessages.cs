﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public static class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "1. Enter employee's name\n2. Enter employee's phone number\n3. Enter employee's age\n4. Display employee information\n5. Display average age of employees\n6. Exit\n-->";
        }

        public static string PromptForName()
        {
            return "Enter employee's name -->";
        }
        public static string PromptForNumber()
        {
            return "Enter employee's phone number -->";
        }
        public static string PromptForAge()
        {
            return "Enter employee's age -->";
        }
        public static string DisplayNumberError()
        {
            return "Not a valid number!";
        }
        public static string DisplayEmployee(string[] name, string[] phone, List<int> age, int index)
        {
            return $"Employee Name- {name[index]}\n" +
                $"Employee Phone- {phone[index]}\n" +
                $"Employee Age- {age[index]}";
        }
    }
}
