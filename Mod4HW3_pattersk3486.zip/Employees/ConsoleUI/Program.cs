﻿//Kevin Patterson
//CSC 253
//11/12/20
//Employees Form
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class Program
    {
        static void Main(string[] args)
        {//create input var for user input and sentury for loop
            string input;
            bool exit = false;
            //create constant var
            const int SIZE = 5;
            int nameIndex = 0, phoneIndex = 0;
            string[] employeeName = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();
           

            
            do
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayMenu());
                input = Console.ReadLine();
                    //Switch to direct to propper process


                    switch (input)

                    {
                        case "1":
                        Console.Write(EmployeeLibrary.StandardMessages.PromptForName());
                            input = Console.ReadLine();
                        EnterName(ref employeeName, ref nameIndex, input);
                            break;
                        case "2":
                        Console.Write(EmployeeLibrary.StandardMessages.PromptForNumber());
                            input = Console.ReadLine();
                        EnterPhone(ref employeePhone, ref phoneIndex, input);
                            break;
                        case "3":
                        Console.Write(EmployeeLibrary.StandardMessages.PromptForAge());
                            input = Console.ReadLine();
                        EnterAge(employeeAge, input);
                            break;
                        case "4":
                        
                        //Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayEmployee());
                        DisplayEmpInfoToUser(employeeName, employeePhone, employeeAge);
                        

                        break;
                        case "5":
                            Console.Write(employeeAge.Average());
                            Console.WriteLine();
                            break;
                        case "6":
                            exit = true;
                            break;
                        default:
                            Console.Write("Not a valid choice!");
                            Console.WriteLine();
                            break;
                    }
                    
            
                } while (exit == false);

        }
        public static void EnterName(ref string[] name, ref int index, string input)
        {
            name[index] = input;
            index++;
            Console.WriteLine();
        }
        public static void EnterPhone(ref string[] phone, ref int index, string input)
        {
            phone[index] = input;
            index++;
            Console.WriteLine();
        }

        public static List<int> EnterAge(List<int> empAge, string input)
        {
            int number = 0;
            List<int> age = new List<int>();
            age = empAge;
            if (int.TryParse(input, out number))
            {
                age.Add(number);
            }
            else
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayNumberError());
            }
            Console.WriteLine();
            return age;
        }
        public static void DisplayEmpInfoToUser(string[] name, string[] phone,List<int> age)
        {
            for (int index = 0; index < age.Count; index++)
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayEmployee(name, phone, age, index));
            }
            Console.WriteLine();
        }
    }
    }

