﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConsoleUI;
using EmployeeLibrary;
namespace EmployeeWinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //const int SIZE = 5;
        //int nameIndex = 0, phoneIndex = 0;
        //string[] employeeName = new string[SIZE];
        //string[] employeePhone = new string[SIZE];
        //List<int> employeeAge = new List<int>();
        private void Name_textBox_TextChanged(object sender, EventArgs e)
        {


        }

        private void Phone_maskedTextBox_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            //Employee_listBox.Items.Add(EmployeeLibrary.StandardMessages.PromptForNumber());
        }

        private void Age_textBox_TextChanged(object sender, EventArgs e)
        {
            //Employee_listBox.Items.Add(EmployeeLibrary.StandardMessages.PromptForAge());
        }

        private void Submit_button_Click(object sender, EventArgs e)
        {
            Employee_listBox.Items.Add($"Name: {Name_textBox.Text}  Phone: {Phone_maskedTextBox.Text}  Age: {Age_textBox.Text}");
            //Employee_listBox.Items.Add(Phone_maskedTextBox.Text);
            //Employee_listBox.Items.Add($"Age : {Age_textBox.Text}");
             //Employee_listBox.Items.Add(EmployeeLibrary.StandardMessages.DisplayEmployee());
            //Employee_listBox.Items.Add($"Name: {Name_textBox} Phone: {Phone_maskedTextBox} Age: {Age_textBox}");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            EmployeeNameLabel.Text = EmployeeLibrary.StandardMessages.PromptForName();
            EmployeePhoneLabel.Text = EmployeeLibrary.StandardMessages.PromptForNumber();
            EmployeeAgeLabel.Text = EmployeeLibrary.StandardMessages.PromptForAge();
        }

       

        private void Employee_listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
