﻿namespace EmployeeWinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EmployeeNameLabel = new System.Windows.Forms.Label();
            this.EmployeePhoneLabel = new System.Windows.Forms.Label();
            this.EmployeeAgeLabel = new System.Windows.Forms.Label();
            this.Submit_button = new System.Windows.Forms.Button();
            this.Employee_listBox = new System.Windows.Forms.ListBox();
            this.Name_textBox = new System.Windows.Forms.TextBox();
            this.Phone_maskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.Age_textBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // EmployeeNameLabel
            // 
            this.EmployeeNameLabel.AutoSize = true;
            this.EmployeeNameLabel.Location = new System.Drawing.Point(12, 9);
            this.EmployeeNameLabel.Name = "EmployeeNameLabel";
            this.EmployeeNameLabel.Size = new System.Drawing.Size(35, 13);
            this.EmployeeNameLabel.TabIndex = 0;
            this.EmployeeNameLabel.Text = "Name";
            // 
            // EmployeePhoneLabel
            // 
            this.EmployeePhoneLabel.AutoSize = true;
            this.EmployeePhoneLabel.Location = new System.Drawing.Point(12, 52);
            this.EmployeePhoneLabel.Name = "EmployeePhoneLabel";
            this.EmployeePhoneLabel.Size = new System.Drawing.Size(78, 13);
            this.EmployeePhoneLabel.TabIndex = 1;
            this.EmployeePhoneLabel.Text = "Phone Number";
            // 
            // EmployeeAgeLabel
            // 
            this.EmployeeAgeLabel.AutoSize = true;
            this.EmployeeAgeLabel.Location = new System.Drawing.Point(15, 99);
            this.EmployeeAgeLabel.Name = "EmployeeAgeLabel";
            this.EmployeeAgeLabel.Size = new System.Drawing.Size(26, 13);
            this.EmployeeAgeLabel.TabIndex = 2;
            this.EmployeeAgeLabel.Text = "Age";
            // 
            // Submit_button
            // 
            this.Submit_button.Location = new System.Drawing.Point(89, 145);
            this.Submit_button.Name = "Submit_button";
            this.Submit_button.Size = new System.Drawing.Size(75, 23);
            this.Submit_button.TabIndex = 3;
            this.Submit_button.Text = "Submit";
            this.Submit_button.UseVisualStyleBackColor = true;
            this.Submit_button.Click += new System.EventHandler(this.Submit_button_Click);
            // 
            // Employee_listBox
            // 
            this.Employee_listBox.FormattingEnabled = true;
            this.Employee_listBox.Location = new System.Drawing.Point(325, 145);
            this.Employee_listBox.Name = "Employee_listBox";
            this.Employee_listBox.Size = new System.Drawing.Size(314, 160);
            this.Employee_listBox.TabIndex = 4;
            this.Employee_listBox.SelectedIndexChanged += new System.EventHandler(this.Employee_listBox_SelectedIndexChanged);
            // 
            // Name_textBox
            // 
            this.Name_textBox.Location = new System.Drawing.Point(167, 9);
            this.Name_textBox.Name = "Name_textBox";
            this.Name_textBox.Size = new System.Drawing.Size(152, 20);
            this.Name_textBox.TabIndex = 5;
            this.Name_textBox.TextChanged += new System.EventHandler(this.Name_textBox_TextChanged);
            // 
            // Phone_maskedTextBox
            // 
            this.Phone_maskedTextBox.Location = new System.Drawing.Point(198, 52);
            this.Phone_maskedTextBox.Mask = "(999) 000-0000";
            this.Phone_maskedTextBox.Name = "Phone_maskedTextBox";
            this.Phone_maskedTextBox.Size = new System.Drawing.Size(152, 20);
            this.Phone_maskedTextBox.TabIndex = 6;
            this.Phone_maskedTextBox.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.Phone_maskedTextBox_MaskInputRejected);
            // 
            // Age_textBox
            // 
            this.Age_textBox.Location = new System.Drawing.Point(167, 99);
            this.Age_textBox.Name = "Age_textBox";
            this.Age_textBox.Size = new System.Drawing.Size(152, 20);
            this.Age_textBox.TabIndex = 7;
            this.Age_textBox.TextChanged += new System.EventHandler(this.Age_textBox_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 317);
            this.Controls.Add(this.Age_textBox);
            this.Controls.Add(this.Phone_maskedTextBox);
            this.Controls.Add(this.Name_textBox);
            this.Controls.Add(this.Employee_listBox);
            this.Controls.Add(this.Submit_button);
            this.Controls.Add(this.EmployeeAgeLabel);
            this.Controls.Add(this.EmployeePhoneLabel);
            this.Controls.Add(this.EmployeeNameLabel);
            this.Name = "Form1";
            this.Text = "Employee Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label EmployeeNameLabel;
        private System.Windows.Forms.Label EmployeePhoneLabel;
        private System.Windows.Forms.Label EmployeeAgeLabel;
        private System.Windows.Forms.Button Submit_button;
        private System.Windows.Forms.ListBox Employee_listBox;
        private System.Windows.Forms.TextBox Name_textBox;
        private System.Windows.Forms.MaskedTextBox Phone_maskedTextBox;
        private System.Windows.Forms.TextBox Age_textBox;
    }
}

