﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
   public class Calc
    {
        public static double CalculateRetail(double wholeSale, double markupPercent)
        {

            double retailPrice = (wholeSale * (markupPercent / 100)) + wholeSale;
            Console.WriteLine("The total retail price is:$ " + retailPrice);
            return retailPrice;
        }
    }
}
