﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleUI;
using Xunit;
namespace RetailCalc.Test
{
    public class RetailTest
    {
        [Theory]
        [InlineData(50, 25, 62.50)]
        public void CalculateRetail(double wholeSale, double markupPercent, double retailPrice)
        {
            //Arrange
            double expected = 62.50;
            //Act
            double actual = wholeSale * (markupPercent / 100) + wholeSale;
            //Assert
            Assert.Equal(retailPrice, actual);
        }
    }
}
