﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using RandomNumbersGenerator;

//Kevin Patterson
//CSC 253-0002
//Rnadom Number file writer
//10/16/2020
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamWriter outputFile;
            int number;
            //try
            //{
                outputFile = File.CreateText("Random Number Generator.txt");
                number = RandomGenerator.GetUserInput(outputFile, number);
                RandomGenerator.SendToFile(outputFile, number);
                RandomGenerator.CloseTheFile(outputFile);
                StandardMessage.CompleteTask();
            //}
            //catch (Exception)
            //{
                //Console.WriteLine("File not found");
            //}
            




        }
    }
}
