﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace RandomNumbersGenerator
{
    public class RandomGenerator
    {
        public static void GetUserInput(StreamWriter outputFile, int number)
        {
            outputFile.WriteLine("How many numbers do you need in the file?");
            int.TryParse(Console.ReadLine(), out number);
        }
        
        public static void SendToFile(StreamWriter outputFile, int number)
        {
            Random rand = new Random();
            for (int i = 0; i < number; i++)
            {
                outputFile.WriteLine(rand.Next(1, 101));
            }
                
        }
        public static void CloseTheFile(StreamWriter outputFile)
        {
            outputFile.Close();
        }
       

    }
}
