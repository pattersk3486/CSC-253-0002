﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomNumbersGenerator
{
    public class StandardMessage
    {
       
        public static void CompleteTask()
        {
            Console.WriteLine("Task is complete.");
            Console.WriteLine("Please open the file in the bin forlder within the ConsoleUI folder.");
        }
    }
}
