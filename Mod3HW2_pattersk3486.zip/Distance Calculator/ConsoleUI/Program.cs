﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
//Kevin Patterson
//CSC-253-0002
//10-06-20
//Distance Calculator

namespace ConsoleUI
{
    class Program
    {
        
        static void Main(string[] args)
        {
            int speed;
            int time;
            int distance;
            StreamWriter outputFile;

            Console.WriteLine("Enter the speed");
            int.TryParse(Console.ReadLine(), out speed);
            Console.WriteLine("Enter the time");
            int.TryParse(Console.ReadLine(), out time);
            distance = time * speed;
            try
            {
                //Distance = Speed x Time                
                outputFile = File.CreateText("Distance Calculator.txt");               
                outputFile.WriteLine($"The distance is {distance}");
                outputFile.Close();

            }
            catch (Exception)
            {
                Console.WriteLine("Error");
            }
            

        }
    }
}
