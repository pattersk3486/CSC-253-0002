﻿namespace WinFormUI
{


    partial class PersonnelDataSet
    {
    }
}

namespace WinFormUI.PersonnelDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
