﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }

        private void detailsButton_Click(object sender, EventArgs e)
        {
            DetailsForm Details = new DetailsForm();
            Details.ShowDialog();
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void highpayButton_Click(object sender, EventArgs e)
        {
            decimal highpay;
            highpay = (decimal) this.employeeTableAdapter.HighestPay();
            MessageBox.Show($"This is the highest pay {highpay}");
        }

        private void lowpayButton_Click(object sender, EventArgs e)
        {
            decimal lowpay;
            lowpay = (decimal)this.employeeTableAdapter.LowestPay();
            MessageBox.Show($"This is the lowest pay {lowpay}");
        }

        private void ascendButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.AscendOrder(this.personnelDataSet.Employee);
        }

        private void descButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.DescOrder(this.personnelDataSet.Employee);
        }
    }
}
